"""Visualization and plotting routines."""
